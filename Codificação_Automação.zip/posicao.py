import pyautogui
import time


time.sleep(5)

print("Tá legal a aula?")
print(pyautogui.position())


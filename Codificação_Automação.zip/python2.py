import pyautogui
import webbrowser
import time
import pandas

print("PyAutoGUI esta funcionando!")
time.sleep(1)

webbrowser.open("file:///Users/anderson/Python Gráficos/IFPR/login.html")

pyautogui.press("enter")

time.sleep(3)  # Dá tempo para o navegador abrir
#pyautogui.click()

pyautogui.click(x=2262, y=562)

pyautogui.write("Anderson")
pyautogui.press("tab")
pyautogui.write("1234")
pyautogui.press("tab")

pyautogui.press("enter")

tabela = pandas.read_csv("base_produtos.csv", sep=";", encoding="utf-8")
time.sleep(3)

for linha in tabela.index:
    pyautogui.click(x=2103, y=326)

    id = tabela.loc[linha,"ID"]
    pyautogui.write(str(id))
    pyautogui.press("tab")

    marca = tabela.loc[linha,"Marca"]
    pyautogui.write(str(marca))
    pyautogui.press("tab")

    tipo = tabela.loc[linha,"Tipo"]
    pyautogui.write(str(tipo))
    pyautogui.press("tab")

    preco = tabela.loc[linha,"Preco"]
    pyautogui.write(str(preco))
    pyautogui.press("tab")

    custo = tabela.loc[linha,"Custo"]
    pyautogui.write(str(custo))
    pyautogui.press("tab")

    obs = tabela.loc[linha,"Obs"]
    pyautogui.write(str(obs))
    pyautogui.press("tab")

    pyautogui.press("enter")


